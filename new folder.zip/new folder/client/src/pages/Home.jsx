import React, { useEffect } from "react";
import axios from "axios";
import styles from "../css/homepage.module.css";

function Home(props) {

  useEffect(() => {
    axios.get("http://localhost:3001/api/birthday")
      .then(res => {

      }).catch(err => {

      })
  }, [])

  return (
    <div className={styles.homeBody}>
      <div>
        other stuffother stuffother stuffother stuffother stuffother stuffother stuffother stuffother stuffother stuffother stuffother stuffother stuffother stuff
      </div>
    </div>
  );
}

export default Home;
