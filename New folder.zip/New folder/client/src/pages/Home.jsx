import React, { useEffect } from "react";
import styles from "../css/homepage.module.css"

function Home(props) {

  return (
    <div className={styles.homeBody}>
      <div>
        other stuffother stuffother stuffother stuffother stuffother stuffother stuffother stuffother stuffother stuffother stuffother stuffother stuffother stuff
      </div>
    </div>
  );
}

export default Home;
