import React from "react";

function CustomerMarkerIcon() {

    return (
        <div>
            test
        </div>
    )
}

export default CustomerMarkerIcon;