import React from "react";
import { GoogleMap, LoadScript } from '@react-google-maps/api';
import "../../../css/map.css"
import CustomMarker from "./CustomMarker";
import Info from "./Info";

function Map(props) {
    const mapStyles = {
        height: "500px",
        width: "100%",
        border: "2px solid black",
        borderRadius: "10px"
    };

    const defaultCenter = {
        lat: 20,
        lng: 0
    };

    return (
        <div>
            <div className="mapHeader">
                <h2>Composer Map</h2>
                <div><Info /></div>
            </div>
            <div>
                <LoadScript googleMapsApiKey="">
                    <GoogleMap mapContainerStyle={mapStyles} zoom={2} center={defaultCenter}>
                        {props.pinData.map((pin, index) => {
                            return <CustomMarker key={index} pinID={pin.id} pinName={pin.name} pinLat={pin.lat} pinLng={pin.lng} />
                        })}
                    </GoogleMap>
                </LoadScript>
            </div>
        </div>
    )
}

export default Map;