import React, { useState } from "react";
import styles from "../../css/playlists.module.css";
import WorkDropdownList from "./WorkDropdownList";
import x from "../../images/x.svg"

function AddWorkToPlaylist(props) {

    const [enteredText, setEnteredText] = useState("");
    const [workToAdd, setWorkToAdd] = useState(null);
    function updateEnteredText(event) {
        const val = event.target.value;
        setEnteredText(val);
        updateDDLOptions(val)
    }

    const [shownWorks, setShownWorks] = useState([]);
    const [inputFieldFocused, setInputFieldFocused] = useState(false);
    function updateDDLOptions(inputText) {
        if (inputText === "" || inputText === null) {
            setShownWorks(props.allWorks);
        }
        else {
            let works = props.allWorks.filter((work) => {
                return work.workTitle.includes(inputText);
            })
            setShownWorks(works);
        }
    }

    function selectWork(workID) {
        let selectedWork = shownWorks.filter(work => {
            return work.workID === workID;
        })[0];

        setWorkToAdd({
            workID: selectedWork.workID,
            title: selectedWork.workTitle,
            complete_name: selectedWork.complete_name,
        })

        // pass up to main form at NewPlaylist.jsx
        props.addWork(selectedWork);
    }

    return (
        <div>
            {workToAdd && <div className={styles.addedWork}>
                <span>{workToAdd.title}</span>
                <span>by {workToAdd.complete_name}</span>
            </div>}

            {!workToAdd && <div className={styles.searchForWorkItem}>
                {/* setTimeout gives enough time to call selectWork() before hiding DDL */}
                <input onFocus={() => setInputFieldFocused(true)} onBlur={() => setTimeout(() => setInputFieldFocused(false), 100)} onInput={updateEnteredText} className={styles.searchForWork} value={enteredText} placeholder="Search for work..." />
                {!props.first && <div className={styles.deleteButton}><img onClick={() => props.destroyItem(props.workID)} src={x} width="20px" /></div>}
                {inputFieldFocused && shownWorks.length > 0 && props.allWorks.length !== shownWorks.length &&
                    <div className={styles.dropdownListParent}>
                        {/* pass worksToAdd to disable already selected choices */}
                        <WorkDropdownList worksToAdd={props.worksToAdd} shownWorks={shownWorks} selectWork={selectWork} />
                    </div>
                }
            </div>}
        </div >


    )
}

export default AddWorkToPlaylist;